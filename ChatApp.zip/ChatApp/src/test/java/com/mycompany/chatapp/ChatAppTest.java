/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ompha
 */
public class ChatAppTest {
    
    public ChatAppTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
   

    /**
     * Test of main method, of class ChatApp.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ChatApp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
     @Test
    
    public void testLogCorrect()
            
    {
        LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertEquals("Welcome" + "Kyle" + " " + "Nkwari"+ ", it is great to see you again" , user.returnLoginStatus("Kyle", "Nkwari", true));
    }
    
    @Test
    
    public void testLogINCORRECT()
            
    {
        LogIn user = new LogIn( "Kyle!!!!!" , "password" , "+27838968976");
         assertEquals(" Username or Password incorrect , please try again." , user.returnLoginStatus("Kyle", "Nkwari", false));
    }
    
    
    @Test
    
    public void testUserNameCorrect()
            
    {
        LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertEquals("UserName Successfuly Captured " , user.getUserNameMessage());
    }
    
    @Test
    
    public void testUserNameIncorrect()
            
    {
        LogIn user = new LogIn( "kyle!!!!!!" , "Ch&&sec@ke99!" , "+27838968976");
         assertEquals("UserName is not correctly formated,"
                 + " please ensure that your username countain an underscore "
                 + "and is no more than five characters in length" , user.getUserNameMessage());
    }
            
    
    @Test
    
    public void testPasswordMessageCorrect(){
        
        LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertEquals("Password is successfuly captured" , user.getPasswordMessage());
    }
    
      @Test
           
    public void testPasswordMessageIncorrect(){
        
        LogIn user = new LogIn( "Kyl_1" , "password" , "+27838968976");
        assertEquals("Password is not correctly formated,"
                 + " please ensure that your password countain a capital letter , a number  , special Character "
                 + "and is at least 8 characters in length" ,user.getPasswordMessage());
    }
    
     @Test
    
    public void testCellPhoneNumberMessageCorrect(){
        
        LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertEquals(" Cellphone number successfuly captured" , user.getCellphoneNumebrMessage());
    }
    
    @Test
           
    public void testCellPhoneNumberMessageIncorrect(){
        
        LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "08966553");
        assertEquals("Cell number is incorrectly formatted or "
                 + "does not contain an international code"
                 + "please correct the number and try again" ,user.getCellphoneNumebrMessage());
    }
    
    @Test
    public void testUserNameReturnTrue()
    {
         LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertTrue(user.checkUserName());
    }
    
    @Test
    public void testUserNameReturnFalse()
    {
         LogIn user = new LogIn( "kyle!!!!!!" , "Ch&&sec@ke99!" , "+27838968976");
         assertFalse(user.checkUserName());
    }
    
     @Test
    public void testPasswordReturnTrue()
    {
         LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertTrue(user.checkPasswordComplexity());
    }
    
    @Test
    public void testPasswordReturnFalse()
    {
         LogIn user = new LogIn( "Kyl_1" , "password" , "+27838968976");
         assertFalse(user.checkPasswordComplexity());
    }
    
     @Test
    public void testCellphoneNumberReturnTrue()
    {
         LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "+27838968976");
         assertTrue(user.checkCellPhoneNumber());
    }
    
    @Test
    public void testCellphoneNumberReturnFalse()
    {
         LogIn user = new LogIn( "Kyl_1" , "Ch&&sec@ke99!" , "08966553");
         assertFalse(user.checkCellPhoneNumber());
    }
    
    
   @Test
public void testLoginUserReturnTrue()
{
    LogIn user = new LogIn("Kyl_1", "Ch&&sec@ke99!", "08966553");
    assertTrue(user.loginUser("Kyl_1", "Ch&&sec@ke99!"));
}
    
   @Test
public void testLoginUserReturnFalse()
{
    LogIn user = new LogIn("Kyl_1", "Ch&&sec@ke99!", "08966553");
    assertFalse(user.loginUser("wrongUsername", "wrongPassword"));
}

    
}
