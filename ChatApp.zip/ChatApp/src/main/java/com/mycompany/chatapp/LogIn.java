/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
public class LogIn {

    
    
    // declaration
      private String firstName;
      private String lastName ;
      private String userName;
      private String password;
      private String cellPhoneNumber;
      
      //creating a constructor
      public LogIn(String userName ,String password ,String cellPhoneNumber  )
     {
      
      this.userName = userName;
       this.password = password;
       this.cellPhoneNumber = cellPhoneNumber;
       
         
     }
     
     public boolean checkUserName(){
         
       return userName.contains("_")&&userName.length()<=5;
       
     }
     
     public boolean checkPasswordComplexity(){
         
         boolean hasCapital = false;
         
         boolean hasNumber = false;
         
         boolean hasSpecialCharacter = false;
         
         
       if (password.length()<8 )
       {
           return false;
       }
       
       for (int i = 0 ; i < password.length(); i++)
       {
           
       char currentCharacter = password.charAt(i);
       
       if( Character.isUpperCase(currentCharacter))
       {
         hasCapital = true;   
               
       }
       else if(Character.isDigit(currentCharacter))
       {
           
       hasNumber = true;
               
       }
       else if(!Character.isLetterOrDigit(currentCharacter))
        {
         hasSpecialCharacter = true;  
        }
       }
       
          return hasSpecialCharacter && hasNumber && hasCapital;

    }
     
     public boolean checkCellPhoneNumber()
     {
         String cellPhoneRegex = ("\\+27\\d{9}$");
         
         return cellPhoneNumber.matches(cellPhoneRegex);
     }
     
     public String getUserNameMessage()
     {
         if(checkUserName())
         {
             return "UserName Successfuly Captured ";
         }
         
         return "UserName is not correctly formated,"
                 + " please ensure that your username countain an underscore "
                 + "and is no more than five characters in length";
             
     }
     
     public String getPasswordMessage()
     {
         if(checkPasswordComplexity())
         {
             return "Password is successfuly captured";
         }
         
         return "Password is not correctly formated,"
                 + " please ensure that your password countain a capital letter , a number  , special Character "
                 + "and is at least 8 characters in length";
     }
     
     public String getCellphoneNumebrMessage()
     {
         if(checkCellPhoneNumber())
         {
             return " Cellphone number successfuly captured";
         }
         
         return "Cell number is incorrectly formatted or "
                 + "does not contain an international code"
                 + "please correct the number and try again";
     }
     
        
        public String registerUser(String userName ,String password ,String cellPhoneNumber ,String firstname ,String lastname ){
            
            if(!checkUserName())
            {
                return getUserNameMessage();
            }
            
            if(!checkPasswordComplexity())
            {
                return getPasswordMessage();
            }
            
            if(!checkCellPhoneNumber())
            {
                return getCellphoneNumebrMessage();
            }
            
            //Storing the inputs
            
       this.userName = userName;
       this.password = password;
       this.cellPhoneNumber = cellPhoneNumber;
       this.firstName = firstname;
       this.lastName = lastname;
         
            return "successful ";
            
        }
       public boolean loginUser(String enteredUsername, String enteredPassword)
{
    return this.userName.equals(enteredUsername) && this.password.equals(enteredPassword);
}
        public String returnLoginStatus(String firstName , String lastname , boolean loggedin)
        {
            if(loggedin)
            {
                return "Welcome" + firstName + " " + lastname+ ", it is great to see you again";
            }else 
            {
                return " Username or Password incorrect , please try again.";
            }
        }
    
}
