/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *  
 * 
 * @author Ompha maluma St105398986
 */
public class ChatApp {

    public static void main(String[] args) {
        
         Scanner input = new Scanner(System.in);
         
       //Declaration
        String firstName = "";
        String lastName = "";
        String userName = "";
        String password = "";
        String cellphoneNumber = "";
        
        boolean ValidUserName;
        boolean ValidPassword  ;
        boolean ValidCellphoneNumber ;
        
        System.out.println("=============================");
        System.out.println("     CHATAPP REGISTRATION     ");
        System.out.println("=============================");
        
        System.out.print("Enter your firstname: ");
        firstName = input.nextLine();
        
        System.out.print("Enter your lasttname: ");
        lastName = input.nextLine();
        
        /*prompting the user to enter the needed information and verifying if its in
         * correct format*/
        do
        {
            System.out.print("Enter Username: ");
            userName = input.nextLine();
            
            LogIn user = new LogIn(userName , "", "" );
            ValidUserName = user.checkUserName();
            
        }while(!ValidUserName);
        
        do
        {
             System.out.print("Enter password: ");
            password = input.nextLine();
            
            LogIn user = new LogIn(  "", password, "");
            ValidPassword = user.checkPasswordComplexity();
            
        }while(!ValidPassword);
        
        do
        {
            System.out.print("Enter cellphoneNumber: ");
            cellphoneNumber = input.nextLine();
            
            LogIn user = new LogIn(  userName , password , cellphoneNumber );
            ValidCellphoneNumber = user.checkCellPhoneNumber();
            
        }while(!ValidCellphoneNumber);
        
         System.out.println("");
        
        LogIn user = new LogIn(  userName , password , cellphoneNumber );
        
        System.out.println(user.getUserNameMessage());
        System.out.println(user.getPasswordMessage());
        System.out.println(user.getCellphoneNumebrMessage());
        
        System.out.println("");  
        System.out.println(" Registeration Successful ");
        
        //Login section
        
        System.out.println("=============================");
        System.out.println("     CHATAPP LOGIN     ");
        System.out.println("=============================");
        
       
           /* promptin the user to inter the login details  and comparing 
        *with thw information given during Registration
        */
           System.out.print("Enter username to login: ");
           String  LogInUserName = input.nextLine();
            
            System.out.print("Enter password to login: ");
            String LogInPassword = input.nextLine();
            
            boolean loggedIn = user.loginUser("Kyl_1", "Ch&&sec@ke99!");
            String status = user.returnLoginStatus("Kyl_1", "Nkwari", loggedIn);
            
            // displaying the output messages
            System.out.println(status);
                   
          input.close();        
        }
    }

